import org.junit.Assert;

import static org.junit.Assert.*;

/**
 * Created by Austin Seber2 on 11/9/2016.
 */
public class BoardTest {

    @org.junit.Test
    public void addTileOverExistingTile() throws Exception {

    }

    @org.junit.Test
    public void getTile() throws Exception {

    }

    @org.junit.Test
    public void getTileNeighbor() throws Exception {

    }

}