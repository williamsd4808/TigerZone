chmod +x get-example
chmod +x post-example
chmod +x watch-example

chmod +x draw-card
chmod +x new-game
chmod +x get-moves
chmod +x place-card
chmod +x place-meeple
chmod +x watch-board
