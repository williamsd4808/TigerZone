package GameState;

public enum Feature {
  FIELD, CITY, ROAD, ENDPOINT, MONASTARY;
}