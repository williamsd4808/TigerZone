package GameState;

public class Tile {
	//2d array 5x5 of tile attributes
	Feature[][] subGrid = new Feature[5][5];
	private final boolean shield = false;
	private final int id = 0;
}