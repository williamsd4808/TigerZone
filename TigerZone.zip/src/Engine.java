import GameState.*;

import java.util.List;

public class Engine {
	private List<Player> players;
	private Deck deck;
	private Board board;
	public Engine() {
		createGame();
	}
	public void createGame() {

	}
	public void generateDeck() {

	}
	public void generateBoard() {

	}
}